package com.skyous.trakkit.ui.splash

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.skyous.trakkit.R

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
    }
}
