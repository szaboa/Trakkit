package com.skyous.domain;

public class MyClass {
}
